CREATE USER 'AuthSampleApp'@'localhost' IDENTIFIED BY 'conestogahi';
GRANT ALL PRIVILEGES ON AuthSample.* TO 'AuthSampleApp'@'localhost' WITH GRANT OPTION;

-- and to drop:
--DROP USER 'AuthSampleApp'@'localhost';

