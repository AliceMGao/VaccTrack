
INSERT INTO Users (email_address, username, password) VALUES
	('pmadziak@conestogac.on.ca','sjones','pwd1'),
	('peter.madziak@gmail.com','lsmith','pwd2'),
	('spantazi@conestogac.on.ca','spantazi','pbkdf2:sha256:150000$7Xa8c3RT$3ff3560884c15b6cc8dfb21bf66d70d0cf399dd5553e50e13273d3a7494bff19');
