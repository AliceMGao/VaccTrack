
DELETE FROM Patients;
DELETE FROM VaccinesRecord;
DELETE FROM Users;
DELETE FROM VaccineNotes;
DELETE FROM VaccineDets;
DELETE FROM Appointments;