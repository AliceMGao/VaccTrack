USE bpdb0;

INSERT INTO Patients (firstName, lastName, healtcard_num, sex, dob, phone, email, address) VALUES ('Anna', 'Jones','6102-947-683-PR','F','1992-02-14','519-362-3546','ajones@gmail.com','45 Surrey St. Cambridge');
INSERT INTO Patients (firstName, lastName, healtcard_num, sex, dob, phone, email, address) VALUES ('Allan', 'Smith','3937-748-879-UD','M','1983-11-30','519-571-1236','asmith@gmail.com','82 Narwhal Crt. Cambridge');
INSERT INTO Patients (firstName, lastName, healtcard_num, sex, dob, phone, email, address) VALUES ('Alex', 'Smith','4812-465-567-RI','F','1989-08-17','519-746-3569','alexsmith@outlook.com','26 Poppins St. Cambridge');
INSERT INTO Patients (firstName, lastName, healtcard_num, sex, dob, phone, email, address) VALUES ('Allanna', 'Smith','5115-326-692-KC','F','1976-05-21','623-234-5673','allanna.smith@outlook.com','127 Main St. Toronto');
INSERT INTO Patients (firstName, lastName, healtcard_num, sex, dob, phone, email, address) VALUES ('Andrea', 'Smith','3103-324-145-PR','F','1965-09-29','664-638-4742','adrea.smith@gmail.com','145 Danish St. Missauga');
INSERT INTO Patients (firstName, lastName, healtcard_num, sex, dob, phone, email, address) VALUES ('Albie', 'Jones','6540-184-394-WP','M','1977-08-23','687-423-7O92','Albjonsies@outlook.com','89 Sundrey Ln. Missauga');
INSERT INTO Patients (firstName, lastName, healtcard_num, sex, dob, phone, email, address) VALUES ('Anthy', 'Jones','6330-275-668-TT','F','1969-11-28','517-232-3352','anthy.jones@gmail.com','721 Gandry Rd. Waterloo');
INSERT INTO Patients (firstName, lastName, healtcard_num, sex, dob, phone, email, address) VALUES ('Ahmed', 'Fahad','4581-130-945-XH','M','1964-12-15','534-763-6574','AFahad@gmail.com','389 Ferry St. Kitchener');

INSERT INTO VaccineDets (Ref_id,main_Name,active_ing,dose,DIN,ATC,type) VALUES (1,'Typhoid VIVOTIF','TYPHOID VACCINE (SALMONELLA TYPHI TY21A)','100000000CFU',00885975,'J07AP01 TYPHOID,ORAL','Schedule D');
INSERT INTO VaccineDets (Ref_id,main_Name,active_ing,dose,DIN,ATC,type) VALUES (2,'Moderna','MRNA-1273 SARS-COV-2','100 MCG / 0.5 ML',02510014,'J07BX OTHER VIRAL VACCINES','COVID-19-IO-Authorization, Schedule D');
INSERT INTO VaccineDets (Ref_id,main_Name,active_ing,dose,DIN,ATC,type) VALUES (3,'Astrazeneca','CHADOX1-S [RECOMBINANT]','50000000000 VP/0.5 ML',02510847,'J07BX OTHER VIRAL VACCINES','COVID-19-IO-Authorization, Schedule D');
INSERT INTO VaccineDets (Ref_id,main_Name,active_ing,dose,DIN,ATC,type) VALUES (4,'Pfizer Biontech','TOZINAMERAN','30 MCG / 0.3 ML',02509210,'J07BX  OTHER VIRAL VACCINES ','COVID-19-IO-Authorization, Schedule D');
INSERT INTO VaccineDets (Ref_id,main_Name,active_ing,dose,DIN,ATC,type) VALUES (5,'ELI Bamlanivimab','BAMLANIVIMAB','700 MG / 20 ML',02508176,'J06B  IMMUNOGLOBULINS','Prescription, Schedule D, COVID-19-IO-Authorization ');

INSERT INTO Users (email_address, username, password,firstName,lastName,title,site_location) VALUES
	('pmadziak@conestogac.on.ca','sjones','pwd1','Sara','Jones','CIO','CGH'),
	('alicegaoglad@gmail.com','Agao','pbkdf2:sha256:150000$dZCjdiix$7e1c301b28baea0bf0ac3d929b0b6c5dc493e8933e77582e413265a29768d240','Alice','Gao','HIM','CGH');

INSERT INTO VaccinesRecord (vaccine_name,date_given,time_given,dose_num,vaccine_id_det,patient_id,provider_id,location) VALUES('Typhoid','2021-01-25','10:25:00',2,1,1,4,'CCGH');
INSERT INTO VaccinesRecord (vaccine_name,date_given,time_given,dose_num,vaccine_id_det,patient_id,provider_id,location) VALUES('Moderna','2021-03-21','11:05:00',1,2,1,4,'CCGH');

INSERT INTO VaccineNotes (patient_id,Rec_id,notes,allergy_issue,provider_id) VALUES (1,1,'N/A','Unknown',3);

INSERT INTO Appointments (patient_id,date_booked,time_booked,provider_id,location) VALUES (7,'2021-03-22','09:30:00',5,'CWGH');