USE bpdb0;

INSERT INTO Measurements (systolic,diastolic,pulse) VALUES (120,80,80);
INSERT INTO Measurements (systolic,diastolic,pulse) VALUES (122,78,90);
