
CREATE TABLE IF NOT EXISTS Patients
(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    firstName VARCHAR(256) NOT NULL,
    lastName VARCHAR(256) NOT NULL,
    healtcard_num VARCHAR(256) NOT NULL,
    sex VARCHAR(256),
    dob VARCHAR(256),
    phone VARCHAR(256),
    email VARCHAR(256),
    address VARCHAR(256)
);

CREATE TABLE IF NOT EXISTS Users
(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email_address VARCHAR(256) NOT NULL UNIQUE,
    username VARCHAR(256) NOT NULL,
    password VARCHAR(256) NOT NULL,
    firstName VARCHAR(256) NOT NULL,
    lastName VARCHAR(256) NOT NULL,
    title VARCHAR(256) NOT NULL,
    site_location VARCHAR(256) NOT NULL
);
CREATE TABLE IF NOT EXISTS VaccineDets
(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    Ref_id INTEGER NOT NULL,
    main_Name VARCHAR(256),
    active_ing VARCHAR(256),
    dose VARCHAR(256),
    DIN INTEGER,
    ATC VARCHAR(256),
    type VARCHAR(256)
);

CREATE TABLE IF NOT EXISTS VaccineNotes
(   
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER,
    Rec_id INTEGER,
    notes TEXT,
    allergy_issue VARCHAR(256),
    provider_id INTEGER,
    time_noted TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES Patients(id) 
);

CREATE TABLE IF NOT EXISTS VaccinesRecord
(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    vaccine_name VARCHAR(256) NOT NULL,
    date_given VARCHAR(256),
    time_given VARCHAR(256),   
    time_recorded TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dose_num INTEGER,
    vaccine_id_det INTEGER,
    provider_id INTEGER,
    patient_id INTEGER NOT NULL,
    location VARCHAR(256),    
    FOREIGN KEY (patient_id) REFERENCES Patients(id)    
);

CREATE TABLE IF NOT EXISTS Appointments
(
	id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER,
    date_booked VARCHAR(256),
    time_booked VARCHAR(256),
    provider_id INTEGER,
    location VARCHAR(256),
    FOREIGN KEY (patient_id) REFERENCES Patients(id)
);

-- OG Measurements table
-- CREATE TABLE IF NOT EXISTS Measurements
-- (
--     id INTEGER PRIMARY KEY AUTOINCREMENT,
--     systolic INT NOT NULL,
--     diastolic INT NOT NULL,
--     pulse INT NOT NULL,    
--     time_recorded TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
--     patient_id INT NOT NULL,    
--     FOREIGN KEY (patient_id) REFERENCES Patients(id)    
-- );