Database abstraction layer was improved
  - MySQL engine DBMS option is possible; default DBMS is sqlite3

apps/M4 folder has the Autocomplete resources



