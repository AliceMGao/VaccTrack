#needs this to fix the fact that modINFO74000 module is not in the same directory
import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../libs')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../apps/M1')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../apps/M2/BPApp')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../apps/M3')))

#import HIM73050
