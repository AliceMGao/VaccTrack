'''
    Copyright (C) 2021 Stefan V. Pantazi (svpantazi@gmail.com)    
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see http://www.gnu.org/licenses/.
'''

import unittest
import import_help
#from HIM73050.db_func import *


from b_eng_vs_french_cookie_example.main import app

class TestClass_FlaskIntro(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
                app.config['TESTING'] = True
                cls.app_test=app.test_client()       
                app
        @classmethod
        def tearDownClass(cls):
                #nothing to do
                pass

        def test_case01_app_index_page_request(self):
                print("#####   "+self.__class__.__name__+".test_case01_app_index_page_request")
                resp = self.app_test.get("/")
                print('response:\n{}\n'.format(resp.data))
                self.assertTrue(resp.status_code==200)

        def test_case02_app_get_english_fruit(self):
                print("#####   "+self.__class__.__name__+".test_case02_measurements_page_request")
                resp = self.app_test.get("/en/fruits")
                print('response:',resp.data)
                self.assertTrue(resp.status_code==200)

        def test_case03_app_get_french_fruit(self):
                print("#####   "+self.__class__.__name__+".test_case02_measurements_page_request")
                resp = self.app_test.get("/fr/fruits")
                print('response:',resp.data)
                self.assertTrue(resp.status_code==200)


if __name__ == '__main__':
        unittest.main()
