'''
    Copyright (C) 2021 Stefan V. Pantazi (svpantazi@gmail.com)    
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see http://www.gnu.org/licenses/.
'''

import unittest
import import_help
from HIM73050.db_func import *

DB_ARGS={
                'engine':'sqlite3',
                'dbpath':'./apps/M2/BPApp/database/sqlite3/',
                'dbname':'bpappdb_test.sqlite'
        }

class TestClass_BPApp_database(unittest.TestCase):

        dbConn=None

        @classmethod
        def setUpClass(cls):
                cls.dbConn=db_connection_open_engine(DB_ARGS)

        @classmethod
        def tearDownClass(cls):
                db_connection_close(cls.dbConn)

        def test_case_create_BPMeasurements_table(self):
                db_query_script_from_file(self.dbConn,DB_ARGS,"schema.sql")

        def test_case_insert_into_BPMeasurements_table(self):
                cursor=db_query(self.dbConn,'SELECT * FROM BPMeasurements')
                result=cursor.fetchall()
                if len(result)==0: #to avoid inserting multiple times
                        db_query_script_from_file(self.dbConn,DB_ARGS,"insert-data.sql")

        def test_case_select_from_BPMeasurements_table(self):
                cursor=db_query(self.dbConn,'SELECT * FROM BPMeasurements')
                print(cursor.fetchall())

if __name__ == '__main__':
        unittest.main()
