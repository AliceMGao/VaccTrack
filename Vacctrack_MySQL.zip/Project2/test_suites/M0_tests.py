import unittest

# Define a fn that takes 3 params:
def myfunc(x, y, z):
        print('inside myfunc: x =', x, ' y =', y, ' z =', z)                        
        return(x,y,z)

TUPLE_VECTOR=(1, 2, 3)

class M0_Tests(unittest.TestCase):

        def test_case01_function_argument_unpacking(self):

                print("   "+self.__class__.__name__+".test_case01() Function argument unpacking")
                #adapted by SP from Peter, Winter 2020

                tuple_vec = (1, 2, 3)
                list_vec = [1, 2, 3]

                # with a dict vec, and its param naming, we don't even
                # have to worry about arg order:
                dict_vec = {'x': 1, 'z': 3, 'y': 2}

                #the usual situation is that a function call requires all the parameters, separately, in the right order
                res0=myfunc(x=1,y=2,z=3)
                print('x=1,y=2,z=3 input --> myfunc --> output:',res0,(type(res0)))
                self.assertTrue(res0==TUPLE_VECTOR)                
                 
                res0=myfunc(1,2,3)
                print('x=1,y=2,z=3 input --> myfunc --> output:',res0,(type(res0)))
                self.assertTrue(res0==TUPLE_VECTOR)                                

                # but we can also use the tuple, list & dict as a means of passing arguments to the fn
                # the use of the * syntax indicates that arguments arrive as a "packaged object" and need unpacking
                # one * indicates that arguments are packed as a tuple or list
                res1=myfunc(*tuple_vec)                
                print(tuple_vec, (type(tuple_vec)), 'input --> myfunc --> output:',res1,(type(res1)))
                self.assertTrue(res1==TUPLE_VECTOR)                
                
                res2=myfunc(*list_vec)
                print(list_vec, (type(list_vec)), 'input --> myfunc --> output:',res2,(type(res2)))
                self.assertTrue(res2==TUPLE_VECTOR)                

                # two *, i.e., ** indicates that arguments are packed as a dictionary
                res3=myfunc(**dict_vec)
                print(dict_vec, (type(dict_vec)), 'input --> myfunc --> output:',res3,(type(res3)))
                self.assertTrue(res3==TUPLE_VECTOR)                

        def test_case02_formatted_strings(self):
                print("   "+self.__class__.__name__+".test_case02() formatted strings")

                # from: http://www.blog.pythonlibrary.org/2017/02/08/new-in-python-formatted-string-literals/
                #
                # and: https://pyformat.info/
                #
                # and: https://medium.com/@skabbass1/a-closer-look-at-how-python-f-strings-work-f197736b3bdb
                #

                import datetime

                name1 = 'John Doe'
                age1 = 17

                output_msg = '{} is {} years old.'.format(name1, age1)
                print(output_msg)
                self.assertTrue(output_msg=='John Doe is 17 years old.')
                
                # Or, using named parameters:
                output_msg = '{name} is {age} years old.'.format(name=name1, age=age1)
                print(output_msg)
                self.assertTrue(output_msg=='John Doe is 17 years old.')                

                net_worth = 12345678.9
                today = datetime.datetime.today().strftime("%m/%d/%Y")

                output_msg ='As of {}, {}\'s net worth is ${:,.2f}.'.format(today, name1, net_worth)
                print(output_msg)
                #this will fail tomorrow, please fix!
                self.assertFalse(output_msg=="As of 01/12/2021, John Doe's net worth is $12,345,678.90.")
    

if __name__ == '__main__':
        unittest.main()