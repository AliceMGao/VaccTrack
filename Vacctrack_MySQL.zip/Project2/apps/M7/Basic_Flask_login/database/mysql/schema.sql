USE AuthSample;

CREATE TABLE Users
(
	id INT NOT NULL AUTO_INCREMENT,
	email_address VARCHAR(256) NOT NULL UNIQUE,
	username VARCHAR(128),
	password VARCHAR(256),
	PRIMARY KEY (id)
);
