USE bpdb0;


CREATE TABLE IF NOT EXISTS Patients
(
    id INT PRIMARY KEY AUTO_INCREMENT,
    firstName VARCHAR(255) NOT NULL,
    lastName VARCHAR(255) NOT NULL,
    healtcard_num VARCHAR(255) NOT NULL,
    sex ENUM('F','M','O'),
    dob DATE,
    phone VARCHAR(255),
    email VARCHAR(255),
    address VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS Users
(
    id INT PRIMARY KEY AUTO_INCREMENT,
    email_address VARCHAR(255) NOT NULL UNIQUE,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    firstName VARCHAR(255) NOT NULL,
    lastName VARCHAR(255) NOT NULL,
    title VARCHAR(255) NOT NULL,
    site_location VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS VaccineDets
(
    id INT PRIMARY KEY AUTO_INCREMENT,
    Ref_id INT NOT NULL,
    main_Name VARCHAR(255),
    active_ing VARCHAR(255),
    dose VARCHAR(255),
    DIN INT,
    ATC VARCHAR(255),
    type VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS VaccineNotes
(   
    id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT,
    Rec_id INT,
    notes TEXT,
    allergy_issue ENUM('Yes','No','Unknown'),
    provider_id INT,
    time_noted TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES Patients(id) 
);

CREATE TABLE IF NOT EXISTS VaccinesRecord
(
    id INT PRIMARY KEY AUTO_INCREMENT,
    vaccine_name VARCHAR(255) NOT NULL,
    date_given DATE,
    time_given TIME,   
    time_recorded TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dose_num INT,
    vaccine_id_det INT,
    provider_id INT,
    patient_id INT,
	location VARCHAR(255),
    FOREIGN KEY (patient_id) REFERENCES Patients(id)
);

CREATE TABLE IF NOT EXISTS Appointments
(
	id INT PRIMARY KEY auto_increment,
    patient_id INT,
    date_booked DATE,
    time_booked TIME,
    provider_id INT,
    location VARCHAR(255),
    FOREIGN KEY (patient_id) REFERENCES Patients(id)
);