
DELETE FROM Measurements;
