# from flask import Flask
from flask import flash, g, render_template, request, make_response, redirect, url_for, jsonify
import setup
from setup import app,_PORT,_HOST,_APP_NAME, _PATIENTS_TABLE,_VACCINE_REC_TABLE,_VACCINE_NOTES_TABLE,_VACCINE_DETAILS_TABLE,_APPOINTMENT_TABLE,_PLACEHOLDER
from HIM73050 import flask_db as fdb

# need to import authentication stuff
from auth import login_required

@app.teardown_appcontext
def close_connection(exception):
    fdb.close_db()

@app.route('/')
def root():
    return render_template('index.html')

@app.route('/main_user')
def main_user():
    return render_template('main_user.html')

@app.route('/patient_select')
@login_required
def select_patient():
    return render_template('patient_selector.html')

@app.route('/patients',methods=['GET', 'POST'])
@login_required
def patients():
    '''Works'''
    if request.method == 'GET':
        patient_list = fdb.query_db_get_all('SELECT * FROM '+_PATIENTS_TABLE)
        print(patient_list)
        return jsonify(patient_list)
    elif request.method == 'POST':
        fName = request.form['fname']
        lName = request.form['lname']
        hlCrdNumber = request.form['hlCrdNumber']
        sex = request.form['sex']
        dob = request.form['dob']
        phone = request.form['phone']
        email = request.form['email']
        address = request.form['address']
        result=fdb.query_db_change('INSERT INTO '+_PATIENTS_TABLE+'(firstName, lastName,healtcard_num,sex,dob,phone,email,address) VALUES ({0}, {0},{0},{0},{0},{0},{0},{0})'.format(_PLACEHOLDER),(fName, lName, hlCrdNumber,sex,dob,phone,email,address))
        if result==None:
            print("Could not insert new record into",_PATIENTS_TABLE)
        return redirect(url_for('select_patient'))

@app.route('/patient/<ptid>/'+_APP_NAME, methods=['GET', 'POST'])
@login_required
def patient(ptid):
    '''Works '''
    if request.method == 'GET':
        patient_info = fdb.query_db_get_one('SELECT * FROM '+_PATIENTS_TABLE+' WHERE id={0}'.format(_PLACEHOLDER),(ptid))   
        #retrieve vaccines record     
        query='SELECT * FROM '+_VACCINE_REC_TABLE+' WHERE patient_id={0}'.format(_PLACEHOLDER) # this IS good enough@
        #no need to join - keeping the patient and recprd dictionary separate, makes it easier/more intuitive to write the template code
        #query='SELECT * FROM '+_MEASUREMENTS_TABLE+' as v JOIN (SELECT * FROM Patients WHERE id={0}) as p ON v.patient_id=p.id'.format(_PLACEHOLDER)
        patient_vaccines = fdb.query_db_get_all(query,(ptid))
        a_query= 'SELECT * FROM '+_APPOINTMENT_TABLE+' WHERE patient_id={0}'.format(_PLACEHOLDER)
        patient_appts = fdb.query_db_get_all(a_query,(ptid))
        return render_template('patient.html', patient=patient_info, vaccines=patient_vaccines,appointments=patient_appts)

    elif request.method == 'POST':
        date_given = request.form['date_given']
        # date_booked = request.form['date_booked']
        # if date_given is not None:
            # Inserting new Vaccine Record
        vaccine_name = request.form['vaccine_name']
        time_given = request.form['time_given']
        dose_num = request.form['doseNum']
        vaccine_det_match = fdb.query_db_get_one('SELECT Ref_id, main_Name FROM '+ _VACCINE_DETAILS_TABLE +' WHERE main_Name ={0}'.format(_PLACEHOLDER),(vaccine_name,))
        vaccine_det_id =vaccine_det_match['Ref_id']
        provider =request.form['provider']
        location =request.form['location']
        fdb.query_db_change('INSERT INTO '+_VACCINE_REC_TABLE+' (vaccine_name,date_given,time_given,dose_num,vaccine_id_det,provider_id,patient_id,location) VALUES ({0}, {0}, {0}, {0}, {0}, {0},{0},{0})'.format(_PLACEHOLDER),(vaccine_name,date_given,time_given,dose_num,vaccine_det_id,provider,ptid,location))
        return redirect(url_for('patient',ptid=ptid))
        # elif date_booked is not None:
        #     # Inserting new Appointment
        #     time_booked = request.form['time_booked']
        #     app_location = request.form['appLocation']
        #     app_provider = request.form['appProvider']
        #     fdb.query_db_change('INSERT INTO '+_APPOINTMENT_TABLE+' (patient_id,date_booked,time_booked,provider_id,location) VALUES ({0},{0},{0},{0},{0})'.format(_PLACEHOLDER),(ptid,date_booked,time_booked,app_provider,app_location))
        #     return redirect(url_for('patient',ptid=ptid))

@app.route('/patient/<ptid>/'+_APP_NAME+'/vaccine/<vid>',methods=['GET','POST']) #
def vaccine(ptid,vid):
    if request.method =="GET":
        patient_info = fdb.query_db_get_one('SELECT * FROM '+_PATIENTS_TABLE+' WHERE id={0}'.format(_PLACEHOLDER),(ptid))                 
        pt_vcns=fdb.query_db_get_one('SELECT * FROM '+_VACCINE_REC_TABLE+' WHERE id = {0}'.format(_PLACEHOLDER), (vid))
        pt_vcns_det_id = pt_vcns['vaccine_id_det']
        vaccine_det_match = fdb.query_db_get_one('SELECT Ref_id, main_Name,active_ing,dose,DIN,ATC,type FROM '+ _VACCINE_DETAILS_TABLE +' WHERE Ref_id ={0}'.format(_PLACEHOLDER),(pt_vcns_det_id,))   
        query='SELECT * FROM '+_VACCINE_NOTES_TABLE+' WHERE patient_id={0} AND Rec_id={0}'.format(_PLACEHOLDER)
        patient_vacc_notes = fdb.query_db_get_all(query,(ptid,vid))
        return render_template('vaccine.html',patient=patient_info, vaccine=pt_vcns, vaccine_det =vaccine_det_match,note_dets=patient_vacc_notes)
    elif request.method =="POST":
        note_details = request.form['notes']
        allergy_flag = request.form['allergy_issue']
        rec_ID = vid
        # provider_id = Uid
        provider =request.form['provider']
        fdb.query_db_change('INSERT INTO '+_VACCINE_NOTES_TABLE+' (patient_id,Rec_id,notes,allergy_issue,provider_id) VALUES ({0},{0},{0},{0},{0})'.format(_PLACEHOLDER),(ptid,rec_ID,note_details,allergy_flag,provider))
        return redirect(url_for('vaccine',ptid=ptid,vid=vid))

@app.route('/patient/<ptid>/'+_APP_NAME+'/appointment',methods=['GET','POST'])
@login_required
def appointment(ptid):
    if request.method == 'GET':
        patient_info = fdb.query_db_get_one('SELECT * FROM '+_PATIENTS_TABLE+' WHERE id={0}'.format(_PLACEHOLDER),(ptid)) 
        return render_template('appointment.html',patient=patient_info)
    elif request.method == 'POST':
        date_booked = request.form['date_booked']
        time_booked = request.form['time_booked']
        app_location = request.form['appLocation']
        app_provider = request.form['appProvider']
        fdb.query_db_change('INSERT INTO '+_APPOINTMENT_TABLE+' (patient_id,date_booked,time_booked,provider_id,location) VALUES ({0},{0},{0},{0},{0})'.format(_PLACEHOLDER),(ptid,date_booked,time_booked,app_provider,app_location))
        flash('Appointment for {0}'.format(date_booked))
        flash('at {0} was booked!'.format(time_booked))
        return redirect(url_for('appointment',ptid=ptid))

if __name__ == '__main__':
    app.run(port=_PORT, host=_HOST)


'''
    Steps for porting v2 to v3, update routers and templates.
    
    1) copy measurements(ptid) router code to a NEW patients() router
    and modify its code so that it manages the patient list (allows listing, selecting patients, adding new patient, etc); 
        this is similar to how multiple measurements list was managed for the ONE patient in v2 app
    2) rename the measurements(ptid) router to patient(ptid) 
        and modify its code so that it will displays information about ONE patient
        and manages their measurement list;
        this is similar to how information about one measurement was managed in v2 app
        (i.e., list, select, add new measurement)
    3) update the measurement(ptid,mid) router
    and modify its code to allow for foth a patient info object and
    a measurement info object be passed along to the templates

    4) rename and modify the templates to reflect the above changes

there is no need to pass the patient argument to the routers; 
there will be a patient ID and a patient_info object
'''